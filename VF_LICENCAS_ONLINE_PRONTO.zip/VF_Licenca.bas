Attribute VB_Name = "VF_Licenca"
Option Explicit
Public Function VFMachineID() As String
 Dim pc As String, usr As String
 pc=Environ$("COMPUTERNAME"): usr=Environ$("USERNAME")
 If pc="" Then pc="PC"
 If usr="" Then usr="USER"
 VFMachineID=pc & "-" & usr
End Function
Public Sub VF_ValidarLicenca()
 Dim http As Object, ws As Worksheet, url As String, key As String, machine As String, body As String, resposta As String
 Set ws=ThisWorkbook.Worksheets(6)
 url=Trim$(CStr(ws.Range("B2").Value)): key=Trim$(CStr(ws.Range("B3").Value)): machine=VFMachineID()
 ws.Range("B8").Value="A VALIDAR...": ws.Range("B6").ClearContents
 If url="" Or InStr(1,url,"https://",vbTextCompare)<>1 Then ws.Range("B8").Value="AGUARDANDO SERVIDOR": VF_BloquearSistema: Exit Sub
 If key="" Or UCase$(key)="VF-XXXX-XXXX-XXXX" Then ws.Range("B8").Value="SEM LICENÇA": VF_BloquearSistema: Exit Sub
 body="{""license_key"":""" & Replace(key,"""","""""") & """,""machine_id"":""" & Replace(machine,"""","""""") & """}"
 On Error GoTo Falha
 Set http=CreateObject("WinHttp.WinHttpRequest.5.1")
 http.Open "POST",url,False: http.SetTimeouts 5000,5000,10000,10000
 http.SetRequestHeader "Content-Type","application/json": http.Send body
 resposta=http.ResponseText
 If http.Status<>200 Then GoTo Falha
 If InStr(1,resposta,"""valid"":true",vbTextCompare)>0 Then
   ws.Range("B8").Value="ATIVA": ws.Range("B6").Value=Now: VF_DesbloquearSistema
 Else
   ws.Range("B8").Value="EXPIRADA / BLOQUEADA / INVÁLIDA": VF_BloquearSistema
 End If
 Exit Sub
Falha:
 ws.Range("B8").Value="SERVIDOR INDISPONÍVEL": VF_BloquearSistema
End Sub
Public Sub VF_Revalidar(): VF_ValidarLicenca: End Sub
Public Sub VF_BloquearSistema()
 Dim s As Worksheet
 On Error Resume Next
 For Each s In ThisWorkbook.Worksheets
  If s.Name<>"LICENÇA" Then s.Visible=xlSheetVeryHidden
 Next s
 ThisWorkbook.Worksheets(6).Visible=xlSheetVisible
 ThisWorkbook.Worksheets(6).Activate
End Sub
Public Sub VF_DesbloquearSistema()
 Dim s As Worksheet
 On Error Resume Next
 For Each s In ThisWorkbook.Worksheets: s.Visible=xlSheetVisible: Next s
End Sub
